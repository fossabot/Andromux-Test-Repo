OWASP Nettacker API Files
=========================

OWASP Nettacker API files are stored in here.

* `__database.py` contains database interaction functions
* `engine.py` is entry point of API and main functions
* `api_core.py` has core functions
* `__start_scan.py` run new scans
* `database.sqlite3` an empty API database for sample, its copy to `~/.owasp-nettacker/database.sqlite3` and stores data i there.