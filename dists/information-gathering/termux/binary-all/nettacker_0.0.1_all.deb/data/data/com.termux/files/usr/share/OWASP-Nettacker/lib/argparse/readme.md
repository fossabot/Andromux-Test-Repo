license: python.org
===================
### argparse

This the same argparse https://docs.python.org/3/library/argparse.html
but we fixed the issue https://github.com/python/cpython/pull/3577
and this library temporary will import from here on windows os until we get a patch.

patch credits: Ali Razmjoo Qalaei, Vahid Behzadan - OWASP Nettacker