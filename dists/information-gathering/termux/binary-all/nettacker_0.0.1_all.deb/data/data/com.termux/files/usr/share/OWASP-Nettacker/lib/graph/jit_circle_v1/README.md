JavaScript InfoVis Toolkit
==========================

The JavaScript InfoVis Toolkit provides tools for creating Interactive Data Visualizations for the Web.

This is the Dev project, users should download the project from http://thejit.org

SAMPLE FILES FROM http://philogb.github.io/jit/demos.html