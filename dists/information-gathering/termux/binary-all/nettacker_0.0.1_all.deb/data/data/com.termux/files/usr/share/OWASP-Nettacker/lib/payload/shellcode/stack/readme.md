OWASP Nettacker - Shellcode - Stack Assistant
=====================================

It's helpful with generating stack stuff!
