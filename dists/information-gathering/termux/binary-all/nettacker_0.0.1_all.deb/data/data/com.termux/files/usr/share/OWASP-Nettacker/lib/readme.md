OWASP Nettacker Libraries and Modules
=====================================

OWASP Nettacker modules and libraries are located in here

* `argparse` argparse fixed library for unicode
* `brute` contains brute force types modules
* `graph` graph modules of the framework
* `html_log` HTML log contents
* `icmp` ICMP library
* `language` contains messages in several languages
* `scan` contains scan types modules
* `vuln` contains vulnerability types modules
* `socks_resolver` resolve address by socks proxy
