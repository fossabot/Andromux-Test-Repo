#!/usr/bin/env python
# -*- coding: utf-8 -*-


def themes():
    return ["Avada", "Centum", "Divi", "IncredibleWP", "THEME", "ThinkResponsive", "acento", "agritourismo-theme",
            "amplus", "archin", "area53", "beach_apollo", "bordeaux-theme", "bulteno-theme", "cuckootap", "curvo",
            "dandelion", "default", "designfolio-plus", "diary", "dimension", "euclid", "gazette", "highlight",
            "kernel-theme", "limon", "linenity", "livewire-edition", "make_a_statement", "medicate", "oxygen-theme",
            "parallax", "persuasion", "radial-theme", "rayoflight-theme", "reganto-theme", "rockstar-theme", "saico",
            "striking_r", "twentysixteen", "switchblade"]
