OWASP Nettacker Socks resolver Library
======================================

OWASP Nettacker socks resolver lib stored in here.