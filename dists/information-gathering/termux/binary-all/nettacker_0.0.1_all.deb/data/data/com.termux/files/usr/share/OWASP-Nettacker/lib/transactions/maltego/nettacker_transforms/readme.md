OWASP Nettacker Transforms
=======================
This folder mainly contains the main `canari` package for the Nettacker.
* `src/` - This contains the main code for the transforms
* `__init__.py` - This is the module instantiation file for this folder
* `MANIFEST.in`, `README`, `.canari`, `.mrbob.ini`, `setup.py` are all automatically generated files
when generating a canari package 