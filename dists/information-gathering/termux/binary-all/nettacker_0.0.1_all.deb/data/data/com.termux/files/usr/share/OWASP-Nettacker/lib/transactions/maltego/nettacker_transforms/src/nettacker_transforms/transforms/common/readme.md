OWASP Nettacker Transforms
=======================
- `entities.py` - This contains the python implementation of the entities. \
We have two types of entities:
1. `NettackerScan` : This is used when performing non brute force scans and vulnerability assessments.
2. `NettackerBrute` : This is used for brute forcing and is derived from the NettackerScan class.
