OWASP Nettacker Transforms
=======================
This folder contains all the scripts for the transforms. Every python file represents a transform.
- `common/` - This folder contains the python implementation of the entities.
All other python files are self explanatory.
