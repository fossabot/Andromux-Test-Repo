OWASP Nettacker Maltego Transactions
=======================
This folder mainly contains all the transactions of the OWASP Nettacker framework.
* `__init__.py` - This is the initialization file
* `nettacker_transforms/` - This contains the maltego transactions for OWASP Nettacker