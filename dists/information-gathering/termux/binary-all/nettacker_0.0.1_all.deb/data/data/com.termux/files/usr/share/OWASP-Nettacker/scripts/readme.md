OWASP Nettacker Scripts
=======================
Script files are located in here.

* `__travis_test__.py` test the framework through the TravisCI
* `nettacker` run OWASP Nettacker through the terminal
* `nettacker.bat` run OWASP Nettacker throough the Windows CMD