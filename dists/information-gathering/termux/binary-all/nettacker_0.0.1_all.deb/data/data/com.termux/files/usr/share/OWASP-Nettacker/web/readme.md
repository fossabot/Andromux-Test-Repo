OWASP Nettacker WebUI
=====================
Web UI files are located in here.

* `static` static files for web UI