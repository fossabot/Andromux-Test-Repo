<?php
$rhversion = "2.0.0";
$white = "\e[97m";
$black = "\e[30m\e[1m";
$yellow = "\e[93m";
$orange = "\e[38;5;208m";
$blue   = "\e[34m";
$lblue  = "\e[36m";
$cln    = "\e[0m";
$green  = "\e[92m";
$fgreen = "\e[32m";
$red    = "\e[91m";
$magenta = "\e[35m";
$bluebg = "\e[44m";
$lbluebg = "\e[106m";
$greenbg = "\e[42m";
$lgreenbg = "\e[102m";
$yellowbg = "\e[43m";
$lyellowbg = "\e[103m";
$redbg = "\e[101m";
$grey = "\e[37m";
$cyan = "\e[36m";
$bold   = "\e[1m";
function redhawk_banner(){
  echo "\e[91;1m
           All In One Tool For\e[36m Information Gathering\e[91m And\e[32m Vulnerability Scanning\e[91m
                                                              .  .  .  .
                                                              .  |  |  .
                                                           .  |        |  .
                                                           .              .
                                              @@@@@      . |  (\.|\/|./)  | .   ___   ____
  ██████╗ ███████╗██████╗    ###     ###    @@@@ @@@@    .   (\ |||||| /)   .  |   | /   /
  ██╔══██╗██╔════╝██╔══██╗   ###     ###   @@@@   @@@@   |  (\  |/  \|  /)  |  |   |/   /
  ██████╔╝█████╗  ██║  ██║   ###########   @@@@@@@@@@@     (\             )    |       /
  ██╔══██╗██╔══╝  ██║  ██║   ###########   @@@@@@@@@@@    (\ \e[93m Ver  2.0.0\e[91m  /)   |       \
  ██║  ██║███████╗██████╔╝   ###     ###   @@@     @@@     \      \/      /    |   |\   \
  ╚═╝  ╚═╝╚══════╝╚═════╝    ###     ###   @@@     @@@      \____/\/\____/     |___| \___\
                                                                |0\/0|
         {C} Coded By - R3D#@X0R_2H1N A.K.A Tuhinshubhra         \/\/
                                                                  \/ \e[97m [$] Shout Out - You ;)
\e[32m
  \n";
}
?>
